/*
	ENGR111_Lib.cpp - library for Cornerstone Project
	Created by Nicholas Hawkins 2024
	Permitted for use in ENGR-111 at the University of Louisville
*/

#include <Arduino.h>
#include <ENGR111_Lib.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);

int _countButton = 0;
int _countGeneric = 0;
int lastDisplaySwitch = millis();

// Make the inputs for each project-specific sensors into generic names, to be assigned later on in begin
/* Project Numbers are as follows:
	1 = Windmill
	2 = MSD
*/
ENGR111_Lib::ENGR111_Lib(int project, int buttonPin, int maxDisp, int interruptPin, int input1, int input2)
{
	_project = project;
	_buttonPin = buttonPin;
	_interruptPin = interruptPin;
	_maxDisp = maxDisp;
	_input1 = input1;
	_input2 = input2;
}

// Initializes Serial, LCD,  interrupts, and pins related to those functions
// Uses a switch-case to manage initialization of input pins for each project
void ENGR111_Lib::begin()
{
	pinMode(_buttonPin, INPUT);
	pinMode(_interruptPin, INPUT);
	Serial.begin(9600);
	lcd.init();
	lcd.backlight();
	attachInterrupt(digitalPinToInterrupt(_buttonPin), incrementButton, FALLING);
	attachInterrupt(digitalPinToInterrupt(_interruptPin), incrementGeneric, FALLING);
	switch(_project)
	{
		case 1:
		// neither input is used
		break;
		case 2:
		pinMode(_input1, OUTPUT); //input1 = trigger of ultrasonic sensor
		pinMode(_input2, INPUT);  //input2 = echo of ultrasonic sensor
		break;
	}
}

// Initialize arrays for possible strings that appear on top or bottom of LCD screen
// This assumes max displays is 20, which should be fine
String msgTop[20] = "";
String msgBot[20] = "";

// non-class function for button ISR
void incrementButton()
{
	if(lastDisplaySwitch + 250 < millis()) 
	{ // this limits how quickly the LCD Display can switch
		lastDisplaySwitch = millis();
		_countButton++;
	}
}

// non-class function for other ISR (windmill tach | MSD flow)
void incrementGeneric()
{
	_countGeneric++;
}

// class function to return other ISR counter
int ENGR111_Lib::getCount()
{
	return _countGeneric;
}

// function to allow user to provide messages for LCD 
void ENGR111_Lib::setDisplay(int dispNum, String msg1, String msg2)
{
	msgTop[dispNum-1] = msg1;
	msgBot[dispNum-1] = msg2;
}

// function that uses button to toggle between LCD messages
void ENGR111_Lib::displayLCD()
{
  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print(msgTop[_countButton%_maxDisp]);
  lcd.setCursor(0, 1);
  lcd.print(msgBot[_countButton%_maxDisp]);
  delay(250);
}

// function to utilize an HC-SR04 ultranosic sensor
// reminder that input1 = trig, input2 = echo
float ENGR111_Lib::distance()
{
  // Clears the trigPin condition
  digitalWrite(_input1, LOW);
  delayMicroseconds(2);
  // Sets the trigPin HIGH (ACTIVE) for 10 microseconds
  digitalWrite(_input1, HIGH);
  delayMicroseconds(10);
  digitalWrite(_input1, LOW);
  // Reads the echoPin, returns the sound wave travel time in microseconds
  long duration = pulseIn(_input2, HIGH);
  // Calculating the distance
  float d = duration * 0.034 / 2; // Speed of sound wave divided by 2 (go and back)
  // Returns the distance in cm
  return d;
}