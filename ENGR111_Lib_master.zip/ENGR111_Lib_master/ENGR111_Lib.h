/*
	ENGR111_Lib.h - library for Cornerstone Project
	Created by Nicholas Hawkins 2024
	Permitted for use in ENGR-111 at the University of Louisville
*/

#ifndef ENGR111_Lib_h
#define ENGR111_Lib_h

#include <Arduino.h>
#include <LiquidCrystal_I2C.h>

class ENGR111_Lib
{
	public:
		ENGR111_Lib(int project, int buttonPin, int maxDisp, int interruptPin, int input1, int input2);
		void begin();
		void displayLCD();
		void setDisplay(int dispNum, String msg1, String msg2);
		float distance();
		int getCount();
	private:
		int _project;
		int _buttonPin;
		int _interruptPin;
		int _maxDisp;
		int _input1;
		int _input2;
		int _trigPin;
		int _echoPin;

};

void incrementButton();
void incrementGeneric();

#endif		